<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * The template for displaying the 404 page
 *
 * Do not overload this file directly. Instead have a look at framework/templates/404.php: you should find all
 * the needed hooks there.
 */

us_load_template( 'templates/404' );
